------Additional Explanation on top of previous submission------
used: https://tools.ietf.org/html/rfc4226, https://tools.ietf.org/html/rfc6238

TOTP is a one time pad which is a time based HOTP, which in turn is a HMAC one time pad. The TOTP algorithm takes current unix time and divides it by 30 (flooring it) to get a time specific message
every 30 seconds to be encrypted with the HMAC-SHA-1 algorithm. This time component is the key difference between HOTP and TOTP. The HOTP algorithm simply truncates the result of the HMAC-SHA-1(K,m) where K is the shared
secret and m (C typically) is the time counting value. HOTP takes the result of the HMAC-SHA-1 and truncates to get a 6 (minimum) to 8 digit result. In our case we use 6 digits, because that's what
Google's Authenticator is using. The truncation is performed by taking the last bit of the resuting hash and using it as an offset. It grabs 4 bytes starting from the index of the string: offset,
offset+1, offset+2, and offset+3. It ANDs each of these bytes with 0xff, except for the first one which gets ANDed with 0x7f because the first byte is ignored (unsigned integer). These four bytes
form the 31 bits binary code which is converted into an integer and we take the last 6 digits with mod 1,000,000 to get our 6 digit decimal number that can be matched with the Google Authenticator
code. The three main parts of TOTP is the time message, the HMAC-SHA-1, and the Truncation computation.







------------------------------- Previous Submission ----------------------------------

Usage: 
python totp.py

OR ./submission.sh

Secret:
whatsecraresthis

Instructions:
This was tested with the iphone google authenticator application. Assuming the android version operates the same, enter in the secret on the google app and choose time based. Then start the program. The program will output the secret and the current OTP code. After 30 seconds it will print out the next code below, and so on.

Requirements:
The libraries should be included in standard python 2, but if not it uses base64, time, hmac, and hashlib.

Description:
The program performs the standard totp algorithm which is simply a time based hotp. It first decodes the secret with base 32 and then calculates the message for hmac based on the unix time/30 because
the google authenticator switches codes every 30 seconds. The returned encryption gets truncated to a six digit integer. The last byte is used as an offset and offset-offset4 hex bits are taken the
resulting portion is AND together with 0x7f, 0xff..., and the remainder of 10^6 is taken to get the 6 digits. This result is the authenticator code reflected in the google app.
