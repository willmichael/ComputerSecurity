#!/bin/bash
python totp.py
